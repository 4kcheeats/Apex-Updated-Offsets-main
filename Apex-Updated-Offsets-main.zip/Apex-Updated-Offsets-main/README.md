# Apex-Updated-Offsets
Updated Offsets For APEX
